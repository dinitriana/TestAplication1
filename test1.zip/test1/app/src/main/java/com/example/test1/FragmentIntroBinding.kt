package com.example.test1

class FragmentIntroBinding {

    val startBtn: Any
}
